export const config = {
  exportType: 'default',
};
