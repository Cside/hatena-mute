import { getOrigin } from './utils';

test('getOrigin', () => expect(getOrigin()).toBe('https://b.hatena.ne.jp/*'));
