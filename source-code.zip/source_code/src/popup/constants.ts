export const EVENT_KEY = {
  MUTED_SITES: 'muted-sites',
  MUTED_WORDS: 'muted-words',
} as const;
