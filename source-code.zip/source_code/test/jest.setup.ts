import '@testing-library/jest-dom';
import './chrome';

afterAll(() => {
  jest.resetAllMocks();
});
